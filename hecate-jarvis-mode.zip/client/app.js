const API = location.origin.includes('localhost') || location.origin.includes('127.0.0.1')
  ? 'http://localhost:8787' : (location.origin.replace(/\/$/,'') || 'http://localhost:8787');

const micBtn = document.getElementById('micBtn');
const sendBtn = document.getElementById('send');
const approveBtn = document.getElementById('approve');
const inputEl = document.getElementById('input');
const outputEl = document.getElementById('output');
const statusEl = document.getElementById('status');
const modeEl = document.getElementById('mode');
const labBtn = document.getElementById('labBtn');
const fieldBtn = document.getElementById('fieldBtn');

// --- WebSocket (optional) ---
let ws;
function connectWS() {
  try {
    const wsUrl = API.replace(/^http/,'ws');
    ws = new WebSocket(wsUrl);
    ws.onmessage = (ev)=> {
      const msg = JSON.parse(ev.data);
      if (msg.type === 'plan') {
        log({event:'plan', ...msg});
      } else if (msg.type === 'acted') {
        log({event:'acted', ...msg});
        modeEl.textContent = msg.state?.mode || modeEl.textContent;
      }
    };
  } catch {}
}
connectWS();

// --- Speech Synthesis (browser fallback) ---
function speakLocal(text){
  try {
    const u = new SpeechSynthesisUtterance(text);
    speechSynthesis.speak(u);
  } catch {}
}

async function speak(text){
  // Try server ElevenLabs; fallback to local
  try {
    const r = await fetch(API + '/tts', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({text})});
    if (r.ok) {
      const blob = await r.blob();
      const url = URL.createObjectURL(blob);
      const audio = new Audio(url);
      audio.play();
      return;
    }
  } catch {}
  speakLocal(text);
}

// --- STT via Web Speech API ---
let listening = false;
let recognizer;
function initSTT(){
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) { statusEl.textContent = 'no STT in browser'; return; }
  recognizer = new SR();
  recognizer.continuous = true;
  recognizer.interimResults = true;
  recognizer.onstart = ()=> { statusEl.textContent = 'listening…'; listening = true; };
  recognizer.onend   = ()=> { statusEl.textContent = 'idle'; listening = false; };
  recognizer.onerror = (e)=> { statusEl.textContent = 'error: ' + e.error; };
  recognizer.onresult = (e)=> {
    let finalText = '';
    for (let i=e.resultIndex; i<e.results.length; i++){
      const t = e.results[i][0].transcript;
      if (e.results[i].isFinal) finalText += t;
    }
    if (finalText) onHeard(finalText.trim());
  };
}
initSTT();

// Activation passphrase: "kick the tires"
let armed = false;
async function onHeard(phrase){
  const lower = phrase.toLowerCase();
  if (!armed && /\bkick the tires\b/.test(lower)) {
    armed = true;
    await speak("I'll light the fires, boss.");
    return;
  }
  if (!armed) return; // ignore until activated
  // quick mode words
  if (/\bfield mode\b/.test(lower)) {
    await sendPlan("field mode");
    return;
  }
  if (/\blab mode\b/.test(lower)) {
    await sendPlan("lab mode");
    return;
  }
  inputEl.value = phrase;
  await sendPlan(phrase);
}

micBtn.onclick = ()=>{
  if (!recognizer) return;
  if (listening) { recognizer.stop(); return; }
  recognizer.start();
};

labBtn.onclick = ()=> sendPlan("lab mode");
fieldBtn.onclick = ()=> sendPlan("field mode");

sendBtn.onclick = ()=> sendPlan(inputEl.value);
approveBtn.onclick = ()=> approve();

async function sendPlan(text){
  const r = await fetch(API + '/nlp', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({text}) });
  const j = await r.json();
  log(j);
  if (j.plan?.speak) {
    await speak(j.plan.speak);
  }
}

async function approve(){
  const last = logs.at(-1);
  const actions = last?.plan?.actions || [];
  const r = await fetch(API + '/act', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({actions, approve:true}) });
  const j = await r.json();
  log(j);
  if (j.ok) await speak("Action executed.");
}

const logs = [];
function log(obj){
  logs.push(obj);
  outputEl.textContent = JSON.stringify(obj, null, 2);
}
