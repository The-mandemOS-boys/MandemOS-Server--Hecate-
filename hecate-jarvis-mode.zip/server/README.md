# Jarvis Mode — Server
Natural language router with optional LLM + ElevenLabs.

## Quickstart
1) `cp .env.example .env` and edit keys (optional).
2) `npm i`
3) `npm start`

Endpoints:
- `POST /nlp {text}` -> {parsed, plan, state}
- `POST /act {actions, approve}` -> executes planned actions
- `POST /tts {text}` -> MP3 (requires ELEVEN_API_KEY)
