// intents.js — rule-based fallback + tool schema
export const TOOLS = {
  "lock_out": {desc: "Isolate/deny access; defensive lockdown.", confirm: true},
  "find_way_in": {desc: "Discovery/ingress planning. Shows options, needs approval.", confirm: true},
  "search": {desc: "General search or reconnaissance (non-destructive).", confirm: false},
  "status": {desc: "Report current mode, uptime, and recent actions.", confirm: false},
  "set_mode": {desc: "Switch between LAB and FIELD modes.", confirm: false},
  "note": {desc: "Take a note / memory pin.", confirm: false}
};

export function naiveIntentParse(text) {
  const t = (text||'').toLowerCase();
  // mode switching
  if (/\b(field|battle) mode\b/.test(t)) return {intent:"set_mode", args:{mode:"FIELD"}};
  if (/\b(lab|sandbox) mode\b/.test(t)) return {intent:"set_mode", args:{mode:"LAB"}};

  // lockout / defensive
  if (/(lock(\s|-)?(them|it)?\s*out|seal it|cut (them|it) off|isolate)/.test(t))
    return {intent:"lock_out", args:{scope:"unspecified"}};

  // ingress / find a way in
  if (/(find a way in|way in|open a door|breach|ingress|get inside)/.test(t))
    return {intent:"find_way_in", args:{target:"unspecified"}};

  // recon / search
  if (/(recon|reconnaissance|scan|search|look around|what's out there|what do you see)/.test(t))
    return {intent:"search", args:{q:text}};

  // status
  if (/(status|report|what's our status|where are we)/.test(t))
    return {intent:"status", args:{}};

  // default to note if says 'remember' or 'note'
  if (/(remember this|make a note|note:)/.test(t))
    return {intent:"note", args:{note:text}};

  return {intent:"search", args:{q:text}};
}

export function toolPlan(intentObj, currMode="LAB") {
  const {intent, args} = intentObj;
  switch (intent) {
    case "lock_out":
      return {
        speak: "Proposing a defensive lockdown. I can segment access and deny ingress vectors. Confirm?",
        confirm: true,
        actions: [{tool:"lock_out", args}]};
    case "find_way_in":
      return {
        speak: "I can propose ingress options: 1) passive recon, 2) credential audit, 3) perimeter test. Choose or approve.",
        confirm: true,
        actions: [{tool:"find_way_in", args}]};
    case "search":
      return {speak: "Running a non-destructive scan and summarizing.", confirm: false, actions:[{tool:"search", args}]};
    case "status":
      return {speak: `You're in ${currMode} mode. Ready for orders.`, confirm: false, actions:[{tool:"status"}]};
    case "set_mode":
      return {speak: `Switching mode to ${args.mode}.`, confirm: false, actions:[{tool:"set_mode", args}]};
    case "note":
      return {speak: "Pinned it to memory.", confirm: false, actions:[{tool:"note", args}]};
    default:
      return {speak: "I have options but need a target. Say 'find a way in' or 'lock them out'.", confirm: false, actions:[]};
  }
}
