// index.js — Jarvis Mode backend (NL router + optional LLM + WS events)
import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import fetch from "node-fetch";
import { WebSocketServer } from "ws";
import { naiveIntentParse, toolPlan } from "./intents.js";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 8787;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || "";
const OPENAI_API_BASE = process.env.OPENAI_API_BASE || "https://api.openai.com/v1";
const OPENAI_MODEL = process.env.OPENAI_MODEL || "gpt-4o-mini";
const ELEVEN_API_KEY = process.env.ELEVEN_API_KEY || "";
const ELEVEN_VOICE_ID = process.env.ELEVEN_VOICE_ID || "21m00Tcm4TlvDq8ikWAM";

let STATE = { mode: "LAB", notes: [], lastActions: [] };

function wsBroadcast(obj){
  const msg = JSON.stringify(obj);
  wss.clients.forEach(c => { try { c.send(msg); } catch {} });
}

async function llmIntent(text) {
  if (!OPENAI_API_KEY) return null;
  try {
    const body = {
      model: OPENAI_MODEL,
      messages: [
        {role:"system", content:"You are Hecate, an operations AI that extracts an intent and structured tool call from natural language. Valid intents: lock_out, find_way_in, search, status, set_mode, note. Always return JSON with fields intent (string) and args (object)."},
        {role:"user", content:text}
      ],
      temperature: 0.2
    };
    const r = await fetch(`${OPENAI_API_BASE}/chat/completions`, {
      method:"POST",
      headers:{ "Authorization": `Bearer ${OPENAI_API_KEY}`, "Content-Type":"application/json" },
      body: JSON.stringify(body)
    });
    const j = await r.json();
    const content = j.choices?.[0]?.message?.content || "";
    // naive JSON extraction
    const match = content.match(/{[\s\S]*}/);
    if (match) return JSON.parse(match[0]);
    return null;
  } catch (e) {
    console.error("LLM intent error:", e);
    return null;
  }
}

app.post("/nlp", async (req, res) => {
  const { text } = req.body || {};
  if (!text) return res.status(400).json({error:"Missing text"});
  let parsed = await llmIntent(text);
  if (!parsed) parsed = naiveIntentParse(text);
  const plan = toolPlan(parsed, STATE.mode);
  res.json({ parsed, plan, state: STATE });
  wsBroadcast({ type:"plan", parsed, plan });
});

app.post("/act", async (req, res) => {
  const { actions=[], approve=false } = req.body || {};
  if (!Array.isArray(actions)) return res.status(400).json({error:"Invalid actions"});
  // Enforce approval on confirm-required flows
  const needsConfirm = actions.some(a => a.tool === "lock_out" || a.tool === "find_way_in");
  if (needsConfirm && !approve) {
    return res.json({ok:false, message:"Approval required."});
  }
  for (const a of actions) {
    if (a.tool === "set_mode" && a.args?.mode) {
      STATE.mode = a.args.mode;
    }
    if (a.tool === "note" && a.args?.note) {
      STATE.notes.push({ts: Date.now(), text: a.args.note});
    }
    STATE.lastActions.unshift({ts: Date.now(), ...a});
  }
  wsBroadcast({ type:"acted", actions, state: STATE });
  res.json({ok:true, state: STATE});
});

// Minimal ElevenLabs relay (optional; client can also TTS locally)
app.post("/tts", async (req, res) => {
  try {
    const { text } = req.body || {};
    if (!ELEVEN_API_KEY) return res.status(400).json({error:"ELEVEN_API_KEY not set"});
    const r = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${ELEVEN_VOICE_ID}`, {
      method:"POST",
      headers: {
        "xi-api-key": ELEVEN_API_KEY,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        text: text || "…",
        model_id: "eleven_multilingual_v2",
        voice_settings: { stability: 0.4, similarity_boost: 0.8 }
      })
    });
    const buf = Buffer.from(await r.arrayBuffer());
    res.setHeader("Content-Type","audio/mpeg");
    res.send(buf);
  } catch (e) {
    res.status(500).json({error:String(e)});
  }
});

// --- WebSocket for live events ---
const server = app.listen(PORT, () => {
  console.log("Jarvis Mode server on", PORT);
});
const wss = new WebSocketServer({ server });
