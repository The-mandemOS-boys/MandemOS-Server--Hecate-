# Hecate — Jarvis Mode (Voice-First NL Control)

This bundle gives you:
- **Hotword + passphrase**: Say “kick the tires”; she replies “I’ll light the fires, boss.” and arms.
- **Natural Language** routing: “find a way in”, “lock them out”, “lab mode”, “field mode”, etc.
- **Approval gates** for destructive actions (lock_out, find_way_in).
- **Voice** both ways: Browser STT + TTS fallback; optional ElevenLabs on the server.
- **Optional LLM**: If you set `OPENAI_API_KEY`, intents use the model; else a strong rules fallback.

## How to run (local, 2 terminals)
1. Server:
   ```bash
   cd server
   cp .env.example .env   # optional: add keys
   npm i
   npm start
   ```
2. Client (simple): open `client/index.html` in your browser (Chrome recommended).
   - Or serve statically: `python3 -m http.server 5500` from `client/`.

## Usage
- Click “Start Listening”, say: **kick the tires** → she: **I'll light the fires, boss.**
- Then speak naturally: “find a way in”, “lock them out”, “field mode”, “status”.
- She proposes a plan. Click **Approve & Execute** to confirm sensitive actions.

## Deploy
- Netlify: deploy `client/` as the site. Point `.env` and server to a small VPS/Render/Railway.
- Railway/Render: deploy `server/` as a Node service.

## Notes
- No external calls are made unless keys are set. Defaults are safe.
- All envs validated by presence; otherwise, graceful fallback.
