// index.js — Hecate daemon (Discord + your own AI via Ollama)
// Node 18+, discord.js v14
import 'dotenv/config';
import express from 'express';
import fetch from 'node-fetch';
import {
  Client, GatewayIntentBits, Partials, Events, REST, Routes, SlashCommandBuilder
} from 'discord.js';
import { askLLM } from './ai/adapter.js';

let SCOPE_MODE = (process.env.SCOPE_MODE || 'LAB').toUpperCase();
let ARMED = false;
const LISTEN_SET = new Set();
const IGNITE_WAIT = new Map(); // userId -> ts when awaiting password
const PENDING = new Map();
const cfg = {
  DISCORD_TOKEN: process.env.DISCORD_TOKEN,
  CLIENT_ID: process.env.CLIENT_ID,
  GUILD_ID: process.env.GUILD_ID,
  WELCOME_CHANNEL_ID: process.env.WELCOME_CHANNEL_ID || null,
  PORT: process.env.PORT || 3000
};

if (!cfg.DISCORD_TOKEN || !cfg.CLIENT_ID) {
  console.error('[Hecate] Missing DISCORD_TOKEN or CLIENT_ID in env.');
}

// --- Express (health / keepalive) ---
const app = express();
app.get('/', (_req, res) => res.send('Hecate is awake.'));
app.get('/health', (_req, res) => res.json({ ok: true }));
app.listen(cfg.PORT, () => console.log(`[Hecate] Web up on :${cfg.PORT}`));

// --- Discord client ---
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
  ],
  partials: [Partials.Channel]
});

// --- Register slash commands ---
const commands = [
  new SlashCommandBuilder()
    .setName('ask')
    .setDescription('Ask Hecate (your local AI)')
    .addStringOption(opt => opt.setName('q').setDescription('Your question').setRequired(true))
].map(c => c.toJSON());

async function registerCommands() {
  try {
    const rest = new REST({ version: '10' }).setToken(cfg.DISCORD_TOKEN);
    await rest.put(Routes.applicationCommands(cfg.CLIENT_ID), { body: commandsExt2 });
    console.log('[Hecate] Slash commands registered globally.');
  } catch (err) {
    console.error('[Hecate] Slash command register failed:', err);
  }
}

client.once(Events.ClientReady, async () => {
  console.log(`[Hecate] Logged in as ${client.user.tag}`);
  await registerCommands();
});

client.on(Events.InteractionCreate, async (interaction) => {
  try {
    if (!interaction.isChatInputCommand()) return;
    if (interaction.commandName === 'ask') {
      const q = interaction.options.getString('q', true);
      await interaction.deferReply();
      const reply = await askLLM(q, interaction.user?.username || 'User');
      appendFinding({ tool: 'ask', user: interaction.user?.id, params: { q }, output: reply.slice(0,400)});
        await interaction.editReply(reply.slice(0, 1990));
    }
  } catch (err) {
    console.error('[Hecate] Interaction error:', err);
    if (interaction.deferred || interaction.replied) {
      await interaction.editReply('⚠️ Error talking to the daemon.');
    } else {
      await interaction.reply({ content: '⚠️ Error talking to the daemon.', ephemeral: true });
    }
  }
});

// Lightweight mention handler (no prefix needed)

  // NL OPS HOOK
  client.on(Events.MessageCreate, async (msg) => {
    try {
      if (msg.author.bot) return;
      const content = (msg.content||'').trim();
      const mentioned = msg.mentions.users.has(client.user.id);
      const isDM = ['DM', 1, 3].includes(msg.channel?.type);
      const addr = mentioned || isDM;
      if (!addr) return;

      // Natural language confirm: "confirm <id>" or "approve <id>"
      const m = content.match(/\b(confirm|approve)\s+([a-z0-9]{6,10})\b/i);
      if (m) {
        const id = m[2];
        const rec = PENDING.get(id);
        if (!rec) return void msg.reply('No such pending op.');
        if (!ARMED) return void msg.reply('Ops are disarmed. Admin must /arm first.');
        if (!isAdmin(msg.author.id)) return void msg.reply('Not authorized to confirm.');
        PENDING.delete(id);
        const out = await executeOp(rec.parsed);
        appendFinding({ tool: `op:${rec.parsed.action}`, user: msg.author.id, params: rec.parsed, output: out.slice(0,400)});
        return void msg.reply(out.slice(0,1990));
      }

      // Try to parse an op from natural language
      const parsed = parseOp(content);
      if (parsed && parsed.action) {
        // LAB guard
        if (SCOPE_MODE === 'LAB' && parsed.host && !['juice','dvwa'].includes(parsed.host)) {
          return void msg.reply('LAB mode only allows juice/dvwa.');
        }
        // Admin-only for mode/allow changes
        if (['set_mode','set_allow'].includes(parsed.action) && !isAdmin(msg.author.id)) {
          return void msg.reply('Not authorized to change scope.');
        }

        // Immediate admin actions
        if (parsed.action === 'set_mode') {
          if (!parsed.args?.mode) return void msg.reply('Specify LAB or FIELD.');
          SCOPE_MODE = parsed.args.mode;
          return void msg.reply(`Scope mode set to **${SCOPE_MODE}**`);
        }
        if (parsed.action === 'set_allow') {
          const hosts = (parsed.args?.hosts||[]).slice(0,50);
          if (!hosts.length) return void msg.reply('Provide hosts/IPs to allow.');
          try { await setRunnerAllowlist(hosts); msg.reply(`Allowlist updated (${hosts.length}).`); } catch { msg.reply('Failed to update runner allowlist.'); }
          return;
        }
        if (parsed.action === 'report') {
          return void msg.reply('Use `/report` to generate and receive the file here.');
        }

        // For attack/defense ops, create pending op id
        const id = Math.random().toString(36).slice(2, 10);
        PENDING.set(id, { user: msg.author.id, parsed, ts: Date.now() });
        return void msg.reply(`Pending op created:\n• id=${id}\n• action=${parsed.action}\n• host=${parsed.host||'(default dvwa)'}\n• args=${JSON.stringify(parsed.args||{})}\n\nReply with **confirm ${id}** to execute.`);
      }
    } catch (err) {
      console.error('[Hecate] NL op error:', err);
    }
  });


client.on(Events.MessageCreate, async (msg) => {
  try {
    if (msg.author.bot) return;
    const isMention = msg.mentions.users.has(client.user.id);
    const direct = msg.channel?.type === 1 || msg.channel?.type === 3; // DM types (compat)
    if (!isMention && !direct) return;

    const prompt = msg.content.replace(/<@!?\d+>/g, '').trim();
    const q = prompt.length ? prompt : 'Hello, Hecate.';
    const reply = await askLLM(q, msg.author?.username || 'User');
    await msg.reply(reply.slice(0, 1990));
  } catch (err) {
    console.error('[Hecate] Msg error:', err);
  }
});

client.login(cfg.DISCORD_TOKEN);


function appendFinding(entry) {
  try {
    const rec = { ts: new Date().toISOString(), mode: SCOPE_MODE, ...entry };
    const p = path.join(process.cwd(), 'findings', 'findings.jsonl');
    fs.mkdirSync(path.dirname(p), { recursive: true });
    fs.appendFileSync(p, JSON.stringify(rec) + '\n', 'utf-8');
  } catch {}
}

async function setRunnerAllowlist(hosts) {
  const RUNNER = process.env.SEC_RUNNER_URL || 'http://sec-runner:8081';
  const RUNNER_KEY = process.env.RUNNER_KEY || '';
  const res = await fetch(`${RUNNER}/config`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ allowHosts: hosts, key: RUNNER_KEY })
  });
  if (!res.ok) throw new Error('Runner rejected allowlist update');
  return await res.json();
}


async function joinUserVoice(interaction) {
  const ch = interaction.member?.voice?.channel;
  if (!ch) { await interaction.reply({ content: 'Join a voice channel first.', ephemeral: true }); return null; }
  const conn = joinVoiceChannel({ channelId: ch.id, guildId: ch.guild.id, adapterCreator: ch.guild.voiceAdapterCreator, selfDeaf: false, selfMute: false });
  await interaction.reply({ content: `Joined **${ch.name}**.`, ephemeral: true });
  return conn;
}

function leaveGuildVoice(guildId) {
  const conn = getVoiceConnection(guildId);
  if (conn) conn.destroy();
}

function hecateReceiverFor(guildId) {
  const conn = getVoiceConnection(guildId);
  return conn?.receiver || null;
}

// Capture audio from a user once and send to STT
async function captureOnceToText(guildId, userId) {
  const recv = hecateReceiverFor(guildId);
  const STT = process.env.STT_URL || 'http://stt:8082';
  if (!recv) return null;
  return await new Promise((resolve) => {
    try {
      const opus = recv.subscribe(userId, { end: { behavior: EndBehaviorType.AfterSilence, duration: 1200 } });
      const dec = new prism.opus.Decoder({ frameSize: 960, channels: 2, rate: 48000 });
      const ff = new prism.FFmpeg({ args: ['-f','s16le','-ar','48000','-ac','2','-i','pipe:0','-ac','1','-ar','16000','-f','s16le','pipe:1'] });
      const chunks = [];
      opus.pipe(dec).pipe(ff).on('data', (d) => chunks.push(d)).on('end', async () => {
        try {
          const buf = Buffer.concat(chunks);
          if (buf.length < 32000) return resolve(''); // too short
          const res = await fetch(`${STT}/stt?sr=16000`, { method: 'POST', headers: { 'Content-Type': 'application/octet-stream' }, body: buf });
          const j = await res.json();
          resolve((j.text||'').trim());
        } catch { resolve(''); }
      }).on('error', () => resolve(''));
    } catch { resolve(''); }
  });
}


/* VOICE CAPTURE LOOP */
setInterval(async () => {
  // Poll for users we've been asked to listen to; if in guild voice, capture once
  try {
    for (const guild of client.guilds.cache.values()) {
      const recv = hecateReceiverFor(guild.id);
      if (!recv) continue;
      for (const uid of Array.from(LISTEN_SET)) {
        // capture short snippet and try parse
        const text = await captureOnceToText(guild.id, uid);
        if (!text) continue;
        const lower = normText(text);
        // ignition handshake
        if (lower.includes("jarvis mode engaged")) {
          IGNITE_WAIT.set(uid, Date.now());
          try { const user = await client.users.fetch(uid); await user.send("🔐 Awaiting passphrase."); } catch {}
          continue;
        }
        const pendingTs = IGNITE_WAIT.get(uid);
        if (pendingTs && (Date.now() - pendingTs) < 30000) {
          if (lower.includes("kick the tires")) {
            ARMED = true;
            IGNITE_WAIT.delete(uid);
            try { const user = await client.users.fetch(uid); await user.send("I’ll light the fires boss."); } catch {}
            continue;
          }
        } else { IGNITE_WAIT.delete(uid); }

        // hotword optional
        const cleaned = lower.startsWith("hecate ") ? lower.replace(/^hecate[ ,:-]*/, "") : lower;
        const parsed = parseOp(cleaned);
        if (parsed && parsed.action) {
          if (SCOPE_MODE === 'LAB' && parsed.host && !['juice','dvwa'].includes(parsed.host)) {
            // ignore out-of-scope
            continue;
          }
                    // admin actions via voice: immediate if user is admin
          if (['set_mode','set_allow'].includes(parsed.action)) {
            try {
              const user = await client.users.fetch(uid);
              if (!isAdmin(uid)) { await user.send('Not authorized to change scope.'); continue; }
              if (parsed.action === 'set_mode') {
                if (!parsed.args?.mode) { await user.send('Specify LAB or FIELD.'); continue; }
                SCOPE_MODE = parsed.args.mode; await user.send(`Scope mode set to **${SCOPE_MODE}**`); continue;
              }
              if (parsed.action === 'set_allow') {
                const hosts = (parsed.args?.hosts||[]).slice(0,50);
                if (!hosts.length) { await user.send('Provide hosts/IPs to allow.'); continue; }
                await setRunnerAllowlist(hosts); await user.send(`Allowlist updated (${hosts.length}).`); continue;
              }
            } catch { /* ignore */ }
          }

          const id = Math.random().toString(36).slice(2, 10);
          PENDING.set(id, { user: uid, parsed, ts: Date.now() });
          try {
            const user = await client.users.fetch(uid);
            await user.send(`🎙️ Heard: "${text}"\nPending op id=${id}\naction=${parsed.action}\nhost=${parsed.host||'(default dvwa)'}\nSay or type **confirm ${id}** to execute (after /arm).`);
          } catch {}
        }
      }
    }
  } catch (e) { /* noop */ }
}, 4000);


function normText(s) {
  return (s||'').toLowerCase().replace(/[^a-z0-9\s:.-]/g,' ').replace(/\s+/g,' ').trim();
}
