from flask import Flask, request, jsonify
from vosk import Model, KaldiRecognizer
import json, os, wave, sys

app = Flask(__name__)
model_path = os.environ.get("MODEL_DIR", "/models/en")
model = Model(model_path)

@app.route('/health', methods=['GET'])
def health():
  return jsonify(ok=True)

@app.route('/stt', methods=['POST'])
def stt():
  # Expect raw PCM 16k mono s16le
  sr = int(request.args.get('sr', '16000'))
  data = request.data
  if not data:
    return jsonify(error="no audio"), 400
  rec = KaldiRecognizer(model, sr)
  rec.SetWords(False)
  rec.AcceptWaveform(data)
  res = rec.Result()
  try:
    j = json.loads(res)
    text = j.get('text','').strip()
  except Exception:
    text = ""
  return jsonify(text=text)

if __name__ == '__main__':
  app.run(host='0.0.0.0', port=8082)
