// ai/adapter.js — pluggable AI layer. Default: Ollama HTTP (your box).
import { chatOllama } from './providers/ollama.js';

const MODE = (process.env.AI_MODE || 'OLLAMA').toUpperCase();

export async function askLLM(userMessage, username='User') {
  const sys = process.env.AI_SYSTEM_PROMPT || 'You are Hecate, a helpful daemon. Be concise, capable, and safe.';
  const msgs = [
    { role: 'system', content: sys },
    { role: 'user', content: `${username}: ${userMessage}` },
  ];

  switch (MODE) {
    case 'OLLAMA':
    default:
      return await chatOllama(msgs);
  }
}
