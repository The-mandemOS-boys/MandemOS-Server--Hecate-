// ai/memory/store.js — simple JSONL memory store
import fs from 'node:fs';
import path from 'node:path';

const MEM_PATH = process.env.MEM_PATH || path.join(process.cwd(), 'ai', 'memory', 'mem.jsonl');
function ensureFile() {
  try { fs.mkdirSync(path.dirname(MEM_PATH), { recursive: true }); } catch {}
  try { fs.closeSync(fs.openSync(MEM_PATH, 'a')); } catch {}
}
ensureFile();

export async function memAdd(entry) {
  const rec = {
    ts: new Date().toISOString(),
    user: entry.user || 'anon',
    type: entry.type || 'note',
    text: (entry.text || '').toString().slice(0, 2000)
  };
  await fs.promises.appendFile(MEM_PATH, JSON.stringify(rec) + '\n', 'utf-8');
  return rec;
}

export async function memAll(limit = 1000) {
  try {
    const data = await fs.promises.readFile(MEM_PATH, 'utf-8');
    const lines = data.trim().split('\n').filter(Boolean);
    const items = lines.slice(-limit).map(l => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
    return items;
  } catch { return []; }
}

export async function memQuery(q, k = 5) {
  q = (q || '').toLowerCase();
  const items = await memAll(2000);
  const scored = items.map((it, idx) => {
    const t = (it.text || '').toLowerCase();
    const score = q && t.includes(q) ? 2 : (q ? 0 : 1);
    return { it, score, idx };
  }).filter(x => x.score > 0).sort((a,b) => b.score - a.score || b.idx - a.idx);
  return scored.slice(0, k).map(x => x.it);
}

export async function memClear() {
  await fs.promises.writeFile(MEM_PATH, '', 'utf-8');
}

export async function memStats() {
  const items = await memAll(100000);
  return { count: items.length };
}
