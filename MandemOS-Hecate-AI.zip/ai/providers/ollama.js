// ai/providers/ollama.js — talk to a local/remote Ollama server via HTTP
import fetch from 'node-fetch';

const OLLAMA_HOST = process.env.OLLAMA_HOST || 'http://localhost:11434';
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || 'llama3.1:8b-instruct';

export async function chatOllama(messages) {
  try {
    // Convert OpenAI-like messages to Ollama format (string prompt)
    const prompt = messages.map(m => `${m.role.toUpperCase()}: ${m.content}`).join('\n\n');
    const res = await fetch(`${OLLAMA_HOST}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: OLLAMA_MODEL,
        messages: messages.map(m => ({ role: m.role, content: m.content })),
        stream: false
      })
    });
    if (!res.ok) {
      const t = await res.text();
      throw new Error(`Ollama HTTP ${res.status}: ${t}`);
    }
    const data = await res.json();
    const out = data?.message?.content || data?.response || JSON.stringify(data);
    return out;
  } catch (err) {
    console.error('[Hecate][Ollama] chat error:', err);
    return '⚠️ Ollama is unreachable. Ensure OLLAMA_HOST and OLLAMA_MODEL are set, and the server is up.';
  }
}
