import express from 'express';
import { execFile } from 'node:child_process';

const PORT = process.env.PORT || 8081;
let ALLOW = (process.env.ALLOW_HOSTS || 'juice,dvwa')
  .split(',').map(s => s.trim()).filter(Boolean);
const SAFE_CMDS = {
  nmap_basic: (host) => (['-sV', '-T4', host])
};

const app = express();
const RUNNER_KEY = process.env.RUNNER_KEY || '';
app.use(express.json());

app.get('/health', (_req, res) => res.json({ ok: true, allow: ALLOW }));

app.post('/scan', (req, res) => {
  try {
    const { host, mode } = req.body || {};
    if (!host || !ALLOW.includes(host)) {
      return res.status(400).json({ error: 'Host not allowed. Use lab hosts only.' });
    }
    const builder = SAFE_CMDS[mode || 'nmap_basic'];
    if (!builder) return res.status(400).json({ error: 'Mode not supported.' });
    const args = builder(host);
    execFile('nmap', args, { timeout: 60_000 }, (err, stdout, stderr) => {
      if (err) return res.status(500).json({ error: 'nmap failed.' });
      // Return summarized output to avoid encouraging misuse
      const lines = stdout.split('\n').slice(0, 200);
      res.json({ host, mode: mode || 'nmap_basic', summary: lines.join('\n') });
    });
  } catch (e) {
    res.status(500).json({ error: 'Internal error.' });
  }
});

app.listen(PORT, () => console.log(`[sec-runner] up on :${PORT}, allow=${ALLOW.join(',')}`));


function baseUrl(host) {
  if (host === 'juice') return 'http://juice:3000';
  if (host === 'dvwa') return 'http://dvwa';
  return null;
}

app.post('/webscan', (req, res) => {
  const { host, tool } = req.body || {};
  if (!host || !ALLOW.includes(host)) return res.status(400).json({ error: 'Host not allowed.' });
  const url = baseUrl(host);
  if (!url) return res.status(400).json({ error: 'Unknown host.' });

  const tools = {
      whatweb: ['whatweb', ['-q', url]],
    nikto_quick: ['nikto', ['-host', url, '-Tuning', '123b', '-nossl']],
    gobuster_dirs: ['gobuster', ['dir', '-u', url, '-w', '/app/wordlists/tiny.txt', '-q', '-t', '10', '--no-color']],
  };
  const spec = tools[tool];
  if (!spec) return res.status(400).json({ error: 'Unsupported tool.' });
  const [cmd, args] = spec;
  execFile(cmd, args, { timeout: 60_000 }, (err, stdout, stderr) => {
    if (err) return res.status(500).json({ error: `${cmd} failed.` });
    res.json({ host, tool, summary: (stdout || '').split('\n').slice(0, 200).join('\n') });
  });
});

app.post('/sqli', (req, res) => {
  const { host } = req.body || {};
  if (!host || !ALLOW.includes(host)) return res.status(400).json({ error: 'Host not allowed.' });
  const url = baseUrl(host);
  if (!url) return res.status(400).json({ error: 'Unknown host.' });
  // Minimal, low-risk detection pass
  const target = host === 'dvwa' ? `${url}/vulnerabilities/sqli/?id=1&Submit=Submit` : url;
  const args = ['-u', target, '--batch', '--level=1', '--risk=1', '--crawl=0', '--random-agent', '--smart', '--flush-session'];
  execFile('sqlmap', args, { timeout: 120_000 }, (err, stdout, stderr) => {
    if (err) return res.status(500).json({ error: 'sqlmap failed.' });
    res.json({ host, tool: 'sqlmap', summary: (stdout || '').split('\n').slice(0, 200).join('\n') });
  });
});

app.post('/credtest', (req, res) => {
  const { host } = req.body || {};
  if (!host || !ALLOW.includes(host)) return res.status(400).json({ error: 'Host not allowed.' });
  if (host !== 'dvwa') return res.status(400).json({ error: 'Hydra demo only supported on dvwa.' });
  const url = 'dvwa';
  // Attempt very small, safe set against DVWA
  const args = ['-l', 'admin', '-P', '/app/wordlists/dvwa-mini.txt', url,
    'http-post-form', '/login.php:username=^USER^&password=^PASS^&Login=Login:F=login', '-t', '2', '-w', '5', '-f'];
  execFile('hydra', args, { timeout: 60_000 }, (err, stdout, stderr) => {
    if (err) return res.status(500).json({ error: 'hydra failed.' });
    res.json({ host, tool: 'hydra', summary: (stdout || '').split('\n').slice(0, 200).join('\n') });
  });
});


app.post('/headers', (req, res) => {
  const { host } = req.body || {};
  if (!host || !ALLOW.includes(host)) return res.status(400).json({ error: 'Host not allowed.' });
  const url = baseUrl(host);
  if (!url) return res.status(400).json({ error: 'Unknown host.' });
  execFile('curl', ['-sI', url], { timeout: 20_000 }, (err, stdout, stderr) => {
    if (err) return res.status(500).json({ error: 'curl failed.' });
    const wanted = ['content-security-policy','x-frame-options','x-content-type-options','referrer-policy','permissions-policy','strict-transport-security'];
    const headers = stdout.split('\n').map(l => l.trim()).filter(Boolean);
    const lower = headers.map(h => h.toLowerCase());
    const findings = wanted.map(h => (lower.find(l => l.startswith(h + ':')) ? f'✅ {h}' : f'⚠️ missing {h}'));
    res.json({ host, tool: 'headers', summary: (['# Response headers review'] + findings).join('\n') });
  });
});


// Update allowlist at runtime (requires key)
app.post('/config', (req, res) => {
  const { allowHosts, key } = req.body || {};
  if (!key || key !== RUNNER_KEY) return res.status(403).json({ error: 'Forbidden' });
  if (!allowHosts || !Array.isArray(allowHosts) || allowHosts.length === 0) {
    return res.status(400).json({ error: 'allowHosts must be non-empty array' });
  }
  ALLOW = allowHosts.map(s => (s||'').trim()).filter(Boolean);
  res.json({ ok: true, allow: ALLOW });
});
