// commands/scan.js — calls internal sec-runner to scan lab hosts only
import 'dotenv/config';
import fetch from 'node-fetch';

const RUNNER = process.env.SEC_RUNNER_URL || 'http://sec-runner:8081';

export async function doScan(host, mode) {
  const res = await fetch(`${RUNNER}/scan`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ host, mode })
  });
  const data = await res.json();
  if (!res.ok) {
    return `Scan failed: ${data?.error || res.statusText}`;
  }
  return [
    `🔎 Scan of **${data.host}** (${data.mode})`,
    '```',
    (data.summary || '').slice(0, 1800),
    '```'
  ].join('\n');
}
