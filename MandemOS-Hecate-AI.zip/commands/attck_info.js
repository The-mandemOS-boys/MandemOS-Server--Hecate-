import fs from 'node:fs';
import path from 'node:path';
const KB = path.join(process.cwd(), 'ai', 'kb', 'attck.json');
export async function attckInfo(tacticQ) {
  const data = JSON.parse(await fs.promises.readFile(KB, 'utf-8'));
  tacticQ = (tacticQ||'').toLowerCase();
  const t = data.find(x => x.tactic.toLowerCase().includes(tacticQ));
  if (!t) return 'No match.';
  return [`**${t.tactic}**`, `techniques:`, ...t.techniques.map(s => `• ${s}`)].join('\n');
}
