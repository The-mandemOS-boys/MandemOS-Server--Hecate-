import 'dotenv/config';
import fetch from 'node-fetch';
const RUNNER = process.env.SEC_RUNNER_URL || 'http://sec-runner:8081';
export async function doCredtest(host) {
  const res = await fetch(`${RUNNER}/credtest`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ host })
  });
  const data = await res.json();
  if (!res.ok) return `Cred test failed: ${data?.error || 'error'}`;
  return ['🔐 Credential test', `host: **${data.host}**`, '```', (data.summary||'').slice(0,1800), '```'].join('\n');
}
