import 'dotenv/config';
import fetch from 'node-fetch';
const RUNNER = process.env.SEC_RUNNER_URL || 'http://sec-runner:8081';
export async function doWebscan(host, tool) {
  const res = await fetch(`${RUNNER}/webscan`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ host, tool })
  });
  const data = await res.json();
  if (!res.ok) return `Webscan failed: ${data?.error || 'error'}`;
  return ['🕸️ Webscan', `host: **${data.host}**`, `tool: **${data.tool}**`, '```', (data.summary||'').slice(0,1800), '```'].join('\n');
}
