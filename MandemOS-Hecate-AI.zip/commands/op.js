// commands/op.js — natural language ops with confirmation + guardrails
import { doScan } from './scan.js';
import { doWebscan } from './webscan.js';
import { doSqli } from './sqli.js';
import { doCredtest } from './credtest.js';
import { doHeaders } from './headers.js';

// Parse natural language into a structured op
export function parseOp(text) {
  const t = (text || '').toLowerCase();

  // detect host candidates
  const hostMatch = t.match(/(juice|dvwa|[a-z0-9._:-]+(?:\.[a-z]{2,})?)/);
  const host = hostMatch ? hostMatch[1] : null;

  let action = null;
  const args = {};

  if (/scan|nmap/.test(t)) action = 'scan';
  else if (/nikto|webscan/.test(t)) { action = 'webscan'; args.tool = 'nikto_quick'; }
  else if (/gobuster|dirs?/.test(t)) { action = 'webscan'; args.tool = 'gobuster_dirs'; }
  else if (/whatweb|fingerprint/.test(t)) { action = 'webscan'; args.tool = 'whatweb'; }
  else if (/sqli|sqlmap/.test(t)) action = 'sqli';
  else if (/cred(test|s)?|hydra/.test(t)) action = 'credtest';
  else if (/headers|harden/.test(t)) action = 'headers';

  // admin intents
  if (/(set\s*)?mode/.test(t)) {
    action = 'set_mode';
    const m = t.match(/(lab|field)/);
    args.mode = m ? m[1].toUpperCase() : null;
  } else if (/(allow|allowlist|scope)/.test(t)) {
    action = 'set_allow';
    // collect host-like tokens; skip dvwa/juice defaults
    const tokens = t.match(/[a-z0-9_.:-]+(?:\.[a-z]{2,})?/g) || [];
    args.hosts = tokens.filter(h => !['dvwa','juice'].includes(h));
  } else if (/report|generate\s+report/.test(t)) {
    action = 'report';
  }

  if (!action) return null;
  return { action, host, args };
}

export async function executeOp(op) {
  const h = op.host || 'dvwa';
  switch (op.action) {
    case 'scan': return await doScan(h, 'nmap_basic');
    case 'webscan': return await doWebscan(h, op.args?.tool || 'nikto_quick');
    case 'sqli': return await doSqli(h);
    case 'credtest': return await doCredtest(h);
    case 'headers': return await doHeaders(h);
    default: return 'Unsupported op.';
  }
}
