import 'dotenv/config';
import fetch from 'node-fetch';
const RUNNER = process.env.SEC_RUNNER_URL || 'http://sec-runner:8081';
export async function doSqli(host) {
  const res = await fetch(`${RUNNER}/sqli`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ host })
  });
  const data = await res.json();
  if (!res.ok) return `SQLi check failed: ${data?.error || 'error'}`;
  return ['💉 SQLi check', `host: **${data.host}**`, '```', (data.summary||'').slice(0,1800), '```'].join('\n');
}
