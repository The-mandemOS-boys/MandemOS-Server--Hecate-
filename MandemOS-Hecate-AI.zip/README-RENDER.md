# Hecate (Your Own AI) — Render + Ollama

This bundle runs Hecate as a **Discord worker** on Render and speaks to your **own AI** hosted via **Ollama** (local box, VPS, or anywhere reachable). No OpenAI required.

## What you need
- Node 18+
- Discord Bot token + Client ID
- An **Ollama** server running a model (e.g. `llama3.1:8b-instruct`)
- (Optional) Tailscale/Cloudflare Tunnel if Render must reach your Ollama on a private network

## Local dev
1. `cp .env.example .env` and fill values.
2. `npm install`
3. `node index.js`
4. In Discord, DM mention the bot or use `/ask q:"hello"`

> If the bot says Ollama is unreachable, ensure your Ollama is running:
> ```bash
> ollama run llama3.1:8b-instruct
> ```
> And that `OLLAMA_HOST` points to it.

## Render deploy
1. Push this folder to GitHub.
2. In Render, **New > Blueprint** and select the repo (uses `render.yaml`).
3. Set env vars (DISCORD_TOKEN, CLIENT_ID, ... OLLAMA_HOST, OLLAMA_MODEL).
4. Deploy. It runs as a **worker** (no idle spin-down dependency on HTTP).

## Notes
- Free tier is fine for the Discord worker; **the AI compute runs on your Ollama server**.
- To keep costs free: run Ollama on your own machine and expose via secure tunnel.
- Swap models by setting `OLLAMA_MODEL` (e.g., `mistral`, `qwen2.5`, etc.).


---

## 🧪 Safe Cyber Lab (built-in)

This repo includes a **Docker lab** for school-friendly red/blue exercises.

- **Internal-only network** (`labnet`, `internal: true`) → no Internet egress.
- Vulnerable targets: **OWASP Juice Shop** (`juice`) and **DVWA** (`dvwa`).
- **sec-runner** service exposes a single POST `/scan` that runs **nmap** with strict allowlist (hosts: `juice`, `dvwa`).
- Hecate adds a **`/scan`** command that calls the runner and returns a summarized report.

### Run the lab locally
```bash
# 1) Fill .env for Hecate bot (Discord IDs, etc.)
cp .env.example .env

# 2) Start the lab
docker compose up --build

# 3) In Discord
/scan host:juice
/scan host:dvwa
```

### Safety constraints by design
- The runner can **only** scan allowlisted hosts inside the **internal** docker network.
- No exploitation modules are included.
- Results are summarized for learning purposes.

> You can extend the runner with additional **safe** analyses (log parsing, headers checks, TLS config), but avoid adding exploit/payload tooling.


### Red/Blue training commands (lab only)
- `/scan host:juice|dvwa` — nmap service scan (safe)
- `/webscan host:juice|dvwa tool:nikto_quick|gobuster_dirs` — quick web checks
- `/sqli host:dvwa` — minimal sqlmap detection pass
- `/credtest host:dvwa` — tiny hydra credential test

All routes are enforced by the runner to only target **juice** or **dvwa** on the internal network.


### Blue-team & Knowledge modules
- `/headers host:juice|dvwa` — check standard security headers
- `/webscan host:... tool:whatweb` — fingerprint tech stack
- `/malware_info name:<family>` — KB lookup for common families
- `/attck_info tactic:<name>` — KB lookup for ATT&CK tactics/techniques

> The KB is local static JSON for offline study. For live CVE feeds, run a separate updater outside the internal lab network.


---

## 🔁 Quick-Swap: Lab ↔ Field

**Env / defaults**
- `SCOPE_MODE=LAB` (only lab hosts)
- `RUNNER_KEY=<secret>` (shared between bot and runner)
- `FIELD_ALLOW_HOSTS=10.0.0.5,portal.example.com` (your authorized scope list)
- `RUNNER_URL=http://sec-runner:8081` (in Compose)

**At runtime (admin-only slash commands)**
- `/set_mode mode:LAB|FIELD` → flips banners & mode
- `/set_allow hosts:comma,separated` → updates runner allowlist live

**Ethics banner**
- Always ensure you have **written authorization** for any non-lab target.
- Hecate records mode & params in `findings/findings.jsonl` and tags reports.

**Reports**
- `/report` → compiles recent findings to Markdown and returns it as a file attachment.
- Export/convert to PDF with your editor if needed.



### Conversational Ops (Jarvis mode, with guardrails)
- `/arm` — enable live ops (admin only)
- `/disarm` — disable live ops
- `/op order:"scan dvwa", "webscan dvwa with gobuster", "sqli dvwa"` — propose
- `/confirm id:<opid>` — execute the pending op
- `/ops_status` — list pending ops

**Rules**
- LAB mode restricts to `juice|dvwa`. FIELD mode + allowlist required for real targets.
- Nothing runs without `/arm` and explicit `/confirm`.
- All ops are logged and appear in `/report`.


**Tip:** In DMs or mentions you can just type:  
- `scan dvwa` → Hecate proposes an op (id shown).  
- `confirm <id>` → executes (only when **/arm** is active).  
- `set mode to field` / `allow 10.0.0.5 portal.example.com` (admin only).  
If she can’t parse it as an op, she answers like a normal AI.


### 🎙️ Voice Control (Tony Stark mode)
- `/summon` — Hecate joins your current voice channel.
- `/ops_listen mode:on` — she will capture brief snippets from **your** mic and run STT locally (Vosk).
- Speak naturally, e.g., “Hecate scan DVWA with gobuster.” She’ll propose an op (id) via DM; say or type “confirm <id>” to run (after `/arm`).
- `/ops_listen mode:off` — stop listening.
- `/leavevc` — leave voice channel.

**Under the hood**
- Local **Vosk** STT runs in `stt-runner` (no cloud keys).
- Audio is decoded from Discord voice, resampled to 16 kHz, then transcribed.
- Guardrails still apply (LAB vs FIELD, allowlist, /arm + confirm).


### 🔐 Voice Ignition & Mode Switching
- Say **“Jarvis mode engaged”** → Hecate prompts for passphrase.
- Say **“kick the tires”** (within ~30s) → Hecate replies **“I’ll light the fires boss.”** and arms ops.
- Say **“set mode to field”** / **“flip to lab”** → switches modes (admin only, immediate).
- Say **“allow 10.0.0.5 portal.example.com”** → updates allowlist (admin only).

> Guardrails stay on: allowlist, LAB vs FIELD, logging, and explicit confirms for ops.
